const { request, response } = require("express");
const Express = require("express");

const app = Express();
app.set(request,response,next => {
     response.header("Access-Control-Allow-Origin","*");
     response.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept");
     next();
});
app.get("/",(request,response) =>{
    response.send("Happy Women's Day to all strong and beautiful ladies out there!");
});
app.listen(3000 ,() => {
    console.log("Listening at 3000");
});